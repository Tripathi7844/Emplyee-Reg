package com.project.employee.spring.employeeReg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeRegApplicationTests {

	@Test
	void contextLoads() {
	}

}
